
        ////////////////////////////////////  BOUTON HAUT DE PAGE
            $(function(){
                $('.btn_up').click(function() {
                  $('html,body').animate({scrollTop: 0}, 800);
                });
            });
    